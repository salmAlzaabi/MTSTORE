# MTcoins - Coin Shop Website

موقع بيع الكوينز MTcoins - متجر رقمي متقدم لبيع الكوينز بنظام سلة تسوق تفاعلي وربط Discord Webhook.

## الميزات الرئيسية

- 🛒 **سلة تسوق متقدمة** - إضافة/حذف/تعديل المنتجات
- 💎 **شراء بكمية مخصصة** - اختر أي كمية تريدها
- 🎨 **تصميم احترافي** - واجهة مستخدم حديثة بألوان جذابة
- ⚡ **أنيميشنات سلسة** - انتقالات وتأثيرات بصرية احترافية
- 🔗 **ربط Discord Webhook** - إرسال الطلبات مباشرة إلى Discord
- 📱 **متجاوب (Responsive)** - يعمل على جميع الأجهزة

## المتطلبات

- Node.js 18+ 
- npm أو pnpm
- حساب Discord مع Webhook URL

## التثبيت والتشغيل

### 1. استنساخ المشروع
```bash
git clone <repository-url>
cd mtcoins
```

### 2. تثبيت الحزم
```bash
npm install
# أو
pnpm install
```

### 3. إضافة Discord Webhook URL
قم بتحديث ملف `client/src/pages/Home.tsx` وأضف رابط Discord Webhook الخاص بك:

```typescript
const webhookUrl = "YOUR_DISCORD_WEBHOOK_URL_HERE";
```

### 4. تشغيل خادم التطوير
```bash
npm run dev
# أو
pnpm dev
```

الموقع سيكون متاحاً على `http://localhost:5173`

## هيكل المشروع

```
mtcoins/
├── client/
│   ├── public/
│   │   ├── products.json          # بيانات المنتجات
│   │   ├── images/                # صور المنتجات
│   │   └── mtcoins-logo.png       # شعار الموقع
│   ├── src/
│   │   ├── pages/
│   │   │   └── Home.tsx           # الصفحة الرئيسية
│   │   ├── components/
│   │   │   └── ui/                # مكونات shadcn/ui
│   │   ├── contexts/              # React contexts
│   │   ├── lib/                   # دوال مساعدة
│   │   ├── App.tsx                # التطبيق الرئيسي
│   │   ├── main.tsx               # نقطة الدخول
│   │   └── index.css              # الأنماط العامة
│   └── package.json
├── server/                        # ملفات الخادم (اختياري)
├── shared/                        # ملفات مشتركة
└── package.json
```

## تخصيص البيانات

### تحديث المنتجات
عدّل ملف `client/public/products.json`:

```json
[
  {
    "id": 1,
    "coins": 1000,
    "price_credits": 2000,
    "image_url": "/images/coins_1000.png",
    "name": "1,000 Coins"
  },
  // أضف المزيد من المنتجات هنا
]
```

### تحديث الشعار
استبدل `client/public/mtcoins-logo.png` بشعارك الخاص.

### تحديث الألوان
عدّل ملف `client/src/index.css` لتغيير نظام الألوان.

## نظام التسعير

- **القاعدة:** 500 كوينز = 1000 كردت
- **المعادلة:** `السعر بالكردت = الكوينز × 2`

## Discord Webhook

### كيفية الحصول على Webhook URL

1. اذهب إلى إعدادات السيرفر في Discord
2. اختر "Webhooks" من القائمة الجانبية
3. انقر على "Create Webhook"
4. اختر القناة التي تريد إرسال الرسائل إليها
5. انسخ الـ URL

### صيغة الرسالة

يتم إرسال الرسائل بصيغة Embed مع التفاصيل التالية:
- الكمية الإجمالية للكوينز
- قيمة الدفع بالكردت
- اسم اللاعب (Discord Username/ID)
- وقت وتاريخ الطلب
- تفاصيل المنتجات

## البناء للإنتاج

```bash
npm run build
# أو
pnpm build
```

سيتم إنشاء ملفات الإنتاج في مجلد `dist/`

## النشر

يمكنك نشر الموقع على:
- **Vercel** - https://vercel.com
- **Netlify** - https://netlify.com
- **GitHub Pages** - https://pages.github.com
- **أي خادم ويب آخر**

## التقنيات المستخدمة

- **React 19** - مكتبة واجهات المستخدم
- **TypeScript** - لغة البرمجة
- **Tailwind CSS 4** - نظام التصميم
- **shadcn/ui** - مكونات واجهة المستخدم
- **Vite** - أداة البناء
- **Wouter** - التوجيه (Routing)
- **Sonner** - إشعارات Toast
- **Lucide React** - أيقونات

## الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الحر.

## الدعم والمساعدة

للمزيد من المعلومات أو الإبلاغ عن مشاكل، يرجى فتح issue في GitHub.

---

تم إنشاؤه بواسطة Manus AI
آخر تحديث: نوفمبر 2025
