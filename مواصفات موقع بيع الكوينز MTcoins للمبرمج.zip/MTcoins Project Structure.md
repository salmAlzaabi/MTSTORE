# MTcoins Project Structure

## ملخص المشروع

موقع بيع الكوينز MTcoins - متجر رقمي متقدم مبني باستخدام React 19 و TypeScript و Tailwind CSS.

## البنية الكاملة للمشروع

```
mtcoins/
│
├── 📁 client/                          # الواجهة الأمامية (Frontend)
│   ├── 📁 public/                      # الملفات الثابتة
│   │   ├── products.json               # بيانات المنتجات (11 باقة)
│   │   ├── mtcoins-logo.png            # شعار الموقع
│   │   └── 📁 images/                  # صور المنتجات
│   │       ├── coins_1000.png
│   │       ├── coins_10000.png
│   │       ├── coins_20000.png
│   │       ├── coins_30000.png
│   │       ├── coins_40000.png
│   │       ├── coins_50000.png
│   │       ├── coins_60000.png
│   │       ├── coins_70000.png
│   │       ├── coins_80000.png
│   │       ├── coins_90000.png
│   │       └── coins_100000.png
│   │
│   └── 📁 src/                         # كود المصدر
│       ├── 📁 pages/                   # صفحات التطبيق
│       │   ├── Home.tsx                # الصفحة الرئيسية (المتجر)
│       │   └── NotFound.tsx            # صفحة 404
│       │
│       ├── 📁 components/              # المكونات القابلة لإعادة الاستخدام
│       │   ├── ErrorBoundary.tsx       # معالج الأخطاء
│       │   ├── ManusDialog.tsx         # مكون Dialog مخصص
│       │   ├── Map.tsx                 # مكون الخريطة
│       │   └── 📁 ui/                  # مكونات shadcn/ui
│       │       ├── dialog.tsx          # مكون Dialog (السلة والشراء)
│       │       ├── button.tsx          # أزرار
│       │       ├── input.tsx           # حقول الإدخال
│       │       ├── card.tsx            # بطاقات
│       │       ├── badge.tsx           # شارات
│       │       ├── toast.tsx           # إشعارات
│       │       └── ... (مكونات أخرى)
│       │
│       ├── 📁 contexts/                # React Contexts
│       │   └── ThemeContext.tsx        # سياق المظهر (Dark/Light)
│       │
│       ├── 📁 hooks/                   # React Custom Hooks
│       │   ├── useComposition.ts       # للتعامل مع IME
│       │   ├── useMobile.tsx           # كشف الأجهزة المحمولة
│       │   └── usePersistFn.ts         # دوال ثابتة
│       │
│       ├── 📁 lib/                     # دوال مساعدة
│       │   └── utils.ts                # دوال عامة (cn, etc)
│       │
│       ├── App.tsx                     # مكون التطبيق الرئيسي
│       ├── main.tsx                    # نقطة الدخول
│       ├── index.css                   # الأنماط العامة + Tailwind
│       └── const.ts                    # الثوابت (شعار، عنوان)
│
├── 📁 server/                          # الخادم (اختياري)
│   └── index.ts                        # ملف الخادم
│
├── 📁 shared/                          # ملفات مشتركة
│   └── const.ts                        # ثوابت مشتركة
│
├── 📁 dist/                            # ملفات الإنتاج (بعد البناء)
│   └── public/
│       ├── assets/
│       │   └── index-[hash].css        # CSS مضغوط
│       └── products.json
│
├── 📄 package.json                     # حزم المشروع والنصوص
├── 📄 tsconfig.json                    # إعدادات TypeScript
├── 📄 tsconfig.node.json               # إعدادات TypeScript للـ Node
├── 📄 vite.config.ts                   # إعدادات Vite
├── 📄 components.json                  # إعدادات shadcn/ui
├── 📄 GITHUB_SETUP.md                  # دليل الإعداد لـ GitHub
├── 📄 todo.md                          # قائمة المهام المنجزة
└── 📄 README.md                        # ملف README الرئيسي
```

## الملفات الرئيسية

### 1. Home.tsx (الصفحة الرئيسية)
**الموقع:** `client/src/pages/Home.tsx`
**الحجم:** ~500 سطر
**الوظيفة:** تطبيق المتجر الكامل

**المحتوى:**
- عرض شبكة المنتجات (11 باقة)
- نافذة السلة (Cart Modal)
- نافذة الشراء بكمية مخصصة
- منطق إضافة/حذف/تعديل السلة
- إرسال الطلبات إلى Discord Webhook
- أنيميشنات وتأثيرات بصرية

### 2. products.json (بيانات المنتجات)
**الموقع:** `client/public/products.json`
**الحجم:** ~1 KB
**الوظيفة:** تخزين بيانات المنتجات

**البنية:**
```json
[
  {
    "id": 1,
    "coins": 1000,
    "price_credits": 2000,
    "image_url": "/images/coins_1000.png",
    "name": "1,000 Coins"
  },
  ...
]
```

### 3. dialog.tsx (مكون Dialog)
**الموقع:** `client/src/components/ui/dialog.tsx`
**الوظيفة:** نافذة منبثقة للسلة والشراء
**الإصلاحات:** استخدام React.forwardRef

### 4. index.css (الأنماط العامة)
**الموقع:** `client/src/index.css`
**المحتوى:**
- استيراد Tailwind CSS
- متغيرات الألوان (Dark theme)
- أنيميشنات مخصصة
- تصميم متجاوب

### 5. App.tsx (التطبيق الرئيسي)
**الموقع:** `client/src/App.tsx`
**الوظيفة:** التطبيق الرئيسي والتوجيه

**المحتوى:**
- ThemeProvider (Dark theme)
- TooltipProvider
- Toaster للإشعارات
- Router (Wouter)

## التقنيات والمكتبات

| التقنية | الإصدار | الاستخدام |
|---------|---------|----------|
| React | 19 | مكتبة واجهات المستخدم |
| TypeScript | 5.x | لغة البرمجة |
| Tailwind CSS | 4.x | نظام التصميم |
| Vite | 5.x | أداة البناء |
| shadcn/ui | latest | مكونات واجهة |
| Wouter | latest | التوجيه (Routing) |
| Sonner | latest | إشعارات Toast |
| Lucide React | latest | أيقونات |
| Radix UI | latest | مكونات أساسية |

## نقاط الدخول الرئيسية

1. **main.tsx** - نقطة دخول React
2. **App.tsx** - مكون التطبيق الرئيسي
3. **Home.tsx** - الصفحة الرئيسية والمتجر

## الميزات المنفذة

✅ شبكة منتجات متجاوبة
✅ سلة تسوق تفاعلية
✅ شراء بكمية مخصصة
✅ حساب السعر الديناميكي
✅ ربط Discord Webhook
✅ أنيميشنات سلسة
✅ تصميم احترافي (Dark theme)
✅ معالجة الأخطاء
✅ إشعارات Toast
✅ متجاوب (Responsive)

## حجم المشروع

- **كود المصدر:** ~9.3 MB (بدون node_modules)
- **node_modules:** ~115 MB
- **الإنتاج:** ~500 KB (مضغوط)

## الملفات المهمة للتعديل

عند نسخ المشروع إلى GitHub، تأكد من تعديل:

1. **Discord Webhook URL** في `client/src/pages/Home.tsx` (السطر 156)
2. **المنتجات** في `client/public/products.json`
3. **الشعار** في `client/public/mtcoins-logo.png`
4. **الألوان** في `client/src/index.css`
5. **المعلومات** في `package.json`

## الأوامر الأساسية

```bash
# تثبيت الحزم
npm install

# تشغيل خادم التطوير
npm run dev

# بناء للإنتاج
npm run build

# معاينة الإنتاج
npm run preview

# التحقق من الأخطاء
npm run lint
```

## الملفات المستثناة من GitHub

عند رفع المشروع، استثن:
- `node_modules/` - سيتم تثبيتها تلقائياً
- `.git/` - إذا كان موجوداً
- `dist/` - سيتم إنشاؤها بعد البناء
- `.env.local` - ملفات البيئة المحلية
- `.vite/` - ملفات التخزين المؤقت

---

تم إنشاؤه: نوفمبر 2025
