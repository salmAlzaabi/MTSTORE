# MTcoins - دليل البدء السريع

## 📦 تحميل الملفات

تم تجهيز ملفات المشروع الكاملة في ملف مضغوط:
- **mtcoins-source.tar.gz** - جميع ملفات المشروع (9.3 MB)

## 🚀 خطوات التثبيت

### 1️⃣ استخراج الملفات
```bash
tar -xzf mtcoins-source.tar.gz
cd mtcoins
```

### 2️⃣ تثبيت الحزم
```bash
npm install
# أو
pnpm install
```

### 3️⃣ إضافة Discord Webhook
عدّل ملف `client/src/pages/Home.tsx` في السطر 156:

```typescript
const webhookUrl = "YOUR_DISCORD_WEBHOOK_URL_HERE";
```

استبدل `YOUR_DISCORD_WEBHOOK_URL_HERE` برابط Discord Webhook الفعلي.

### 4️⃣ تشغيل خادم التطوير
```bash
npm run dev
```

الموقع سيكون متاحاً على: **http://localhost:5173**

## 📝 تخصيص المشروع

### تغيير المنتجات
عدّل `client/public/products.json`:
```json
[
  {
    "id": 1,
    "coins": 1000,
    "price_credits": 2000,
    "image_url": "/images/coins_1000.png",
    "name": "1,000 Coins"
  }
]
```

### تغيير الشعار
استبدل `client/public/mtcoins-logo.png` بشعارك الخاص.

### تغيير الألوان
عدّل `client/src/index.css` وغيّر متغيرات الألوان.

## 🔨 أوامر مهمة

| الأمر | الوصف |
|------|-------|
| `npm run dev` | تشغيل خادم التطوير |
| `npm run build` | بناء للإنتاج |
| `npm run preview` | معاينة الإنتاج |
| `npm run lint` | التحقق من الأخطاء |

## 📤 رفع إلى GitHub

### 1. إنشاء مستودع جديد
```bash
git init
git add .
git commit -m "Initial commit: MTcoins coin shop"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mtcoins.git
git push -u origin main
```

### 2. إضافة .gitignore
تأكد من وجود `.gitignore` يحتوي على:
```
node_modules/
dist/
.env.local
.vite/
.turbo/
```

## 🌐 النشر على الإنترنت

### خيار 1: Vercel (الأفضل)
```bash
npm install -g vercel
vercel
```

### خيار 2: Netlify
```bash
npm install -g netlify-cli
netlify deploy --prod --dir=dist
```

### خيار 3: GitHub Pages
```bash
npm run build
# ثم رفع مجلد dist إلى GitHub Pages
```

## 🐛 حل المشاكل الشائعة

### المشكلة: "Cannot find module"
**الحل:**
```bash
rm -rf node_modules package-lock.json
npm install
```

### المشكلة: Discord Webhook لا يعمل
**الحل:**
- تأكد من صحة رابط Webhook
- تأكد من أن القناة موجودة
- تحقق من صلاحيات الـ Webhook

### المشكلة: الصور لا تظهر
**الحل:**
- تأكد من وجود الصور في `client/public/images/`
- تحقق من أسماء الملفات في `products.json`

## 📱 اختبار على الهاتف

```bash
# احصل على IP الخاص بك
ipconfig getifaddr en0  # macOS/Linux
# أو
ipconfig  # Windows

# ثم افتح في الهاتف:
http://YOUR_IP:5173
```

## 💡 نصائح مهمة

1. **احفظ Discord Webhook في متغير بيئة** بدلاً من الكود مباشرة
2. **استخدم صور عالية الجودة** للمنتجات (1920x1080 على الأقل)
3. **اختبر على أجهزة مختلفة** قبل النشر
4. **راقب الأداء** باستخدام Chrome DevTools

## 📚 موارد إضافية

- [React Documentation](https://react.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [shadcn/ui](https://ui.shadcn.com)
- [Discord Webhooks](https://discord.com/developers/docs/resources/webhook)

## 🎯 الخطوات التالية

1. ✅ استخراج الملفات وتثبيت الحزم
2. ✅ إضافة Discord Webhook
3. ✅ تخصيص المنتجات والألوان
4. ✅ اختبار الموقع محلياً
5. ✅ رفع إلى GitHub
6. ✅ نشر على الإنترنت

---

**تم إنشاؤه:** نوفمبر 2025
**الإصدار:** 1.0.0
